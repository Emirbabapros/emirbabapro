## Discord Sorgu Botu (Özellikler)
- Bot sadece api ile çalisir.
- Sayfa sistemi vardir.
- TXT olarak indirme seçenegi mevcut.

## Kurulum
1. [NodeJS](https://nodejs.org/tr/) kurun.
2. [Discord Developer](https://discord.com/developers/applications) sitesinden bot olusturup token almak
3. "config.js" doldurmak.
3. "baslat.bat" dosyasini çalistirmak.

## Yapimcilar
- [Discord](https://discord.gg/perlaservis) sunucumuzda bulabilirsiniz.
- Discord: Atahan#7104 / Hoster#0001

## Not
- Configdeki apiler için [Discord](https://discord.gg/perlaservis) sunucusuna gelip almaniz tavsiye edilir.

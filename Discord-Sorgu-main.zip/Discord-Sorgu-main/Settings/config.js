﻿module.exports = {

    token: "", //Bot tokeni
    owners: [""], //Bot sahipleri
    guildID: "",

    roller: {

        SORGUCU: "1087505959007567872", //Sorgucu rolü

    },

    emojiler: {

        UPLOAD: "" || "📑", //Upload emojisi

    },
    
    api: {

        ADSOYAD: "https://perlaservis.net", //Ad soyad api
        AD: "https://perlaservis.net", //Ad api
        SOYAD: "https://perlaservis.net", //Soyad api
        TCKN: "https://perlaservis.net", //Tc api
        TCKNPRO: "https://perlaservis.net", //Serino api
        AILE: "https://perlaservis.net", //Aile api
        SULALE: "https://perlaservis.net", //Sulale api
        EOKUL: "https://perlaservis.net", //E-okul api
        AOL: "https://perlaservis.net", //Aöl api
        ADRES: "https://perlaservis.net", //Adres api
        TCGSM: "https://perlaservis.net", //Tc gsm api
        GSMTC: "https://perlaservis.net", //Gsm tc api
        ASI: "https://perlaservis.net", //Aşı api
        ILAC: "https://perlaservis.net", //İlaç api

    }

}
